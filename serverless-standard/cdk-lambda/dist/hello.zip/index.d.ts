export declare const lambdaHandler: (event: any, context: any) => Promise<string>;
